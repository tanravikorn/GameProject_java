package logic.candy;

public enum CandyColor {
    RED,
    GREEN,
    YELLOW,
    PURPLE,
    BLUE,
    NONE,
}
