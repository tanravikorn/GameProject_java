package logic.candy;

public enum CandyType {
    NORMAL,
    STRIPED_HOR,
    STRIPED_VER,
    BOMB,
    COLOR_BOMB
}

