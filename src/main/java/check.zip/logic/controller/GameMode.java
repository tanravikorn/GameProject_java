package logic.controller;

public enum GameMode {
    NORMAL,
    HARD
}
