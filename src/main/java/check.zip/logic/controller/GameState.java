package logic.controller;

public enum GameState {
    PLAY,
    PROCESS,
    GAME_OVER
}
